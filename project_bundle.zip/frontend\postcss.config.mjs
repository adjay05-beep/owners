const config = {
  plugins: {
    "@tailwindcss/postcss": {},
    "postcss-preset-mantine": {},
  },
};

export default config;
